package com.mycompany.nextup

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
