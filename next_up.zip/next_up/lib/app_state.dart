import 'package:flutter/material.dart';
import '/backend/api_requests/api_manager.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {}

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  int _setappointment = 0;
  int get setappointment => _setappointment;
  set setappointment(int value) {
    _setappointment = value;
  }

  int _counterofdone = 0;
  int get counterofdone => _counterofdone;
  set counterofdone(int value) {
    _counterofdone = value;
  }

  List<String> _adate = [];
  List<String> get adate => _adate;
  set adate(List<String> value) {
    _adate = value;
  }

  void addToAdate(String value) {
    adate.add(value);
  }

  void removeFromAdate(String value) {
    adate.remove(value);
  }

  void removeAtIndexFromAdate(int index) {
    adate.removeAt(index);
  }

  void updateAdateAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    adate[index] = updateFn(_adate[index]);
  }

  void insertAtIndexInAdate(int index, String value) {
    adate.insert(index, value);
  }

  List<String> _atime = [];
  List<String> get atime => _atime;
  set atime(List<String> value) {
    _atime = value;
  }

  void addToAtime(String value) {
    atime.add(value);
  }

  void removeFromAtime(String value) {
    atime.remove(value);
  }

  void removeAtIndexFromAtime(int index) {
    atime.removeAt(index);
  }

  void updateAtimeAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    atime[index] = updateFn(_atime[index]);
  }

  void insertAtIndexInAtime(int index, String value) {
    atime.insert(index, value);
  }

  List<String> _aoffice = [];
  List<String> get aoffice => _aoffice;
  set aoffice(List<String> value) {
    _aoffice = value;
  }

  void addToAoffice(String value) {
    aoffice.add(value);
  }

  void removeFromAoffice(String value) {
    aoffice.remove(value);
  }

  void removeAtIndexFromAoffice(int index) {
    aoffice.removeAt(index);
  }

  void updateAofficeAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    aoffice[index] = updateFn(_aoffice[index]);
  }

  void insertAtIndexInAoffice(int index, String value) {
    aoffice.insert(index, value);
  }

  List<String> _atype = [];
  List<String> get atype => _atype;
  set atype(List<String> value) {
    _atype = value;
  }

  void addToAtype(String value) {
    atype.add(value);
  }

  void removeFromAtype(String value) {
    atype.remove(value);
  }

  void removeAtIndexFromAtype(int index) {
    atype.removeAt(index);
  }

  void updateAtypeAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    atype[index] = updateFn(_atype[index]);
  }

  void insertAtIndexInAtype(int index, String value) {
    atype.insert(index, value);
  }

  String _name = '';
  String get name => _name;
  set name(String value) {
    _name = value;
  }

  String _email = '';
  String get email => _email;
  set email(String value) {
    _email = value;
  }

  String _srcode = '';
  String get srcode => _srcode;
  set srcode(String value) {
    _srcode = value;
  }

  String _program = '';
  String get program => _program;
  set program(String value) {
    _program = value;
  }

  List<String> _list = [];
  List<String> get list => _list;
  set list(List<String> value) {
    _list = value;
  }

  void addToList(String value) {
    list.add(value);
  }

  void removeFromList(String value) {
    list.remove(value);
  }

  void removeAtIndexFromList(int index) {
    list.removeAt(index);
  }

  void updateListAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    list[index] = updateFn(_list[index]);
  }

  void insertAtIndexInList(int index, String value) {
    list.insert(index, value);
  }
}
