import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import '/index.dart';
import 'student_information_in_queue_widget.dart'
    show StudentInformationInQueueWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class StudentInformationInQueueModel
    extends FlutterFlowModel<StudentInformationInQueueWidget> {
  ///  Local state fields for this component.

  int? confirmantionofdone = 1;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
