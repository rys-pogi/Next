import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/foundation.dart';

import '/flutter_flow/flutter_flow_util.dart';
import 'api_manager.dart';

export 'api_manager.dart' show ApiCallResponse;

const _kPrivateApiFunctionName = 'ffPrivateApiCall';

class AppointmentCreateCall {
  static Future<ApiCallResponse> call({
    String? date = '16/06/2025',
    String? time = '3:00 pm',
    String? type = 'ctc',
    String? office = 'registrar',
    String? name = 'harry',
    int? id = 11,
    int? qnumber = 9,
  }) async {
    final ffApiRequestBody = '''
{
  "id": "${escapeStringForJson(name)}",
  "title": "${escapeStringForJson(type)}",
  "description": "${escapeStringForJson(type)}",
  "date": "${escapeStringForJson(date)}",
  "time": "${escapeStringForJson(time)}",
  "userId": ${id},
  "name": "${escapeStringForJson(name)}",
  "phone_number": "${escapeStringForJson(name)}",
  "location": "${escapeStringForJson(office)}",
  "queue_number": ${qnumber}
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'appointment create',
      apiUrl: 'https://backendup-82e29b7b83f9.herokuapp.com/appointments',
      callType: ApiCallType.POST,
      headers: {},
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class GetListCall {
  static Future<ApiCallResponse> call() async {
    return ApiManager.instance.makeApiCall(
      callName: 'get list',
      apiUrl: 'https://backendup-82e29b7b83f9.herokuapp.com/appointments',
      callType: ApiCallType.GET,
      headers: {},
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class GetNamesCall {
  static Future<ApiCallResponse> call({
    List<String>? namesList,
  }) async {
    final names = _serializeList(namesList);

    return ApiManager.instance.makeApiCall(
      callName: 'get names',
      apiUrl: 'https://backendup-82e29b7b83f9.herokuapp.com/appointments/names',
      callType: ApiCallType.GET,
      headers: {},
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class GetDataCall {
  static Future<ApiCallResponse> call({
    int? id = 1,
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'get data',
      apiUrl: 'https://backendup-82e29b7b83f9.herokuapp.com/appointments/${id}',
      callType: ApiCallType.GET,
      headers: {},
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }

  static String? title(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.title''',
      ));
  static String? date(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.date''',
      ));
  static String? time(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.time''',
      ));
  static String? name(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.name''',
      ));
  static String? office(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.location''',
      ));
}

class ApiPagingParams {
  int nextPageNumber = 0;
  int numItems = 0;
  dynamic lastResponse;

  ApiPagingParams({
    required this.nextPageNumber,
    required this.numItems,
    required this.lastResponse,
  });

  @override
  String toString() =>
      'PagingParams(nextPageNumber: $nextPageNumber, numItems: $numItems, lastResponse: $lastResponse,)';
}

String _toEncodable(dynamic item) {
  return item;
}

String _serializeList(List? list) {
  list ??= <String>[];
  try {
    return json.encode(list, toEncodable: _toEncodable);
  } catch (_) {
    if (kDebugMode) {
      print("List serialization failed. Returning empty list.");
    }
    return '[]';
  }
}

String _serializeJson(dynamic jsonVar, [bool isList = false]) {
  jsonVar ??= (isList ? [] : {});
  try {
    return json.encode(jsonVar, toEncodable: _toEncodable);
  } catch (_) {
    if (kDebugMode) {
      print("Json serialization failed. Returning empty json.");
    }
    return isList ? '[]' : '{}';
  }
}

String? escapeStringForJson(String? input) {
  if (input == null) {
    return null;
  }
  return input
      .replaceAll('\\', '\\\\')
      .replaceAll('"', '\\"')
      .replaceAll('\n', '\\n')
      .replaceAll('\t', '\\t');
}
