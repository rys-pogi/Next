// Export pages
export '/pages/log_in_page/log_in_page_widget.dart' show LogInPageWidget;
export '/pages/sign_up_page/sign_up_page_widget.dart' show SignUpPageWidget;
export '/pages/role_page/role_page_widget.dart' show RolePageWidget;
export '/pages/staff_dashboard_page/staff_dashboard_page_widget.dart'
    show StaffDashboardPageWidget;
export '/pages/student_dashboard_page/student_dashboard_page_widget.dart'
    show StudentDashboardPageWidget;
export '/pages/student_details_page/student_details_page_widget.dart'
    show StudentDetailsPageWidget;
export '/pages/staff_approving_page/staff_approving_page_widget.dart'
    show StaffApprovingPageWidget;
export '/pages/staff_details_page/staff_details_page_widget.dart'
    show StaffDetailsPageWidget;
export '/pages/student_no_app_dashboard/student_no_app_dashboard_widget.dart'
    show StudentNoAppDashboardWidget;
export '/pages/sudent_inbox_page/sudent_inbox_page_widget.dart'
    show SudentInboxPageWidget;
export '/student_information_inqueue_popup/student_information_inqueue_popup_widget.dart'
    show StudentInformationInqueuePopupWidget;
export '/pages/staff_dashboard_page_copy/staff_dashboard_page_copy_widget.dart'
    show StaffDashboardPageCopyWidget;
export '/pages/landing_page/landing_page_widget.dart' show LandingPageWidget;
